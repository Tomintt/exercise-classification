package com.example.myapplication

import android.Manifest
import android.content.pm.PackageManager
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.Bundle
import android.util.Log
import android.widget.ScrollView
import android.widget.TextView
import androidx.activity.ComponentActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import java.io.BufferedWriter
import java.io.File
import java.io.FileOutputStream
import java.io.OutputStreamWriter

class MainActivity : ComponentActivity(), SensorEventListener {
    private var sensorManager: SensorManager? = null
    private var accelerometer: Sensor? = null
    private var gyroscope: Sensor? = null
    private var textView: TextView? = null

    private var lastAccelData = "Accelerometer:\nX: 0.0\nY: 0.0\nZ: 0.0\n\n"
    private var lastGyroData = "Gyroscope:\nX: 0.0\nY: 0.0\nZ: 0.0\n\n"

    private val fileName = "sensor_data.csv"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        checkStoragePermission()

        val scrollView = ScrollView(this)
        textView = TextView(this)
        textView!!.text = "Accelerometer & Gyroscope Data\n\n"
        textView!!.textSize = 24f
        scrollView.addView(textView)
        setContentView(scrollView)

        sensorManager = getSystemService(SENSOR_SERVICE) as SensorManager
        accelerometer = sensorManager!!.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)
        gyroscope = sensorManager!!.getDefaultSensor(Sensor.TYPE_GYROSCOPE)

        // Register the listeners as soon as the app starts
        sensorManager?.registerListener(this, accelerometer, SensorManager.SENSOR_DELAY_UI)
        sensorManager?.registerListener(this, gyroscope, SensorManager.SENSOR_DELAY_UI)

        initializeCSVFile()
    }

    override fun onResume() {
        super.onResume()
        sensorManager?.registerListener(this, accelerometer, SensorManager.SENSOR_DELAY_UI)
        sensorManager?.registerListener(this, gyroscope, SensorManager.SENSOR_DELAY_UI)
        Log.d("SensorStatus", "Sensors re-registered on resume")
    }


    private fun checkStoragePermission() {
        if (ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.WRITE_EXTERNAL_STORAGE
            ) != PackageManager.PERMISSION_GRANTED ||
            ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.READ_EXTERNAL_STORAGE
            ) != PackageManager.PERMISSION_GRANTED
        ) {
            ActivityCompat.requestPermissions(
                this,
                arrayOf(
                    Manifest.permission.WRITE_EXTERNAL_STORAGE,
                    Manifest.permission.READ_EXTERNAL_STORAGE
                ),
                REQUEST_CODE_STORAGE_PERMISSION
            )
        } else {
            Log.d("Permission", "Storage permission already granted")
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == REQUEST_CODE_STORAGE_PERMISSION) {
            if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                Log.d("Permission", "Storage permission granted")
            } else {
                Log.e("Permission", "Storage permission denied")
            }
        }
    }

    override fun onSensorChanged(event: SensorEvent?) {
        if (event != null) {
            when (event.sensor.type) {
                Sensor.TYPE_ACCELEROMETER -> {
                    lastAccelData = String.format(
                        "Accelerometer:\nX: %.2f\nY: %.2f\nZ: %.2f\n\n",
                        event.values[0], event.values[1], event.values[2]
                    )
                    Log.d("AccelerometerData", lastAccelData)
                    saveToCSV("Accelerometer", event.values[0], event.values[1], event.values[2])
                }

                Sensor.TYPE_GYROSCOPE -> {
                    lastGyroData = String.format(
                        "Gyroscope:\nX: %.2f\nY: %.2f\nZ: %.2f\n\n",
                        event.values[0], event.values[1], event.values[2]
                    )
                    Log.d("GyroscopeData", lastGyroData)
                    saveToCSV("Gyroscope", event.values[0], event.values[1], event.values[2])
                }
            }
            textView!!.text = lastAccelData + lastGyroData
        }
    }

    override fun onAccuracyChanged(sensor: Sensor, accuracy: Int) {
    }

    override fun onPause() {
        super.onPause()
        sensorManager!!.unregisterListener(this)
    }

    private fun initializeCSVFile() {
        val externalDir = getExternalFilesDir(null)
        val file = File(externalDir, fileName)

        try {
            // Always overwrite the file at the start
            BufferedWriter(OutputStreamWriter(FileOutputStream(file, false))).use { writer ->
                writer.write("Sensor,Timestamp,X,Y,Z\n")  // Write headers on every run
            }
            Log.d("FilePath", "CSV file created at: " + file.absolutePath)
        } catch (e: Exception) {
            Log.e("CSVError", "Error initializing CSV file", e)
        }
    }

    private fun saveToCSV(sensorType: String, x: Float, y: Float, z: Float) {
        val timestamp = System.currentTimeMillis()
        val externalDir = getExternalFilesDir(null)
        val file = File(externalDir, fileName)

        try {
            // Append data after file is overwritten
            BufferedWriter(OutputStreamWriter(FileOutputStream(file, true))).use { writer ->
                writer.write(
                    "$sensorType,$timestamp,$x,$y,$z\n"
                )
            }
            Log.d("CSVWrite", "Data saved to CSV: $sensorType, $timestamp, $x, $y, $z")
        } catch (e: Exception) {
            Log.e("CSVError", "Error writing to CSV file", e)
        }
    }

    companion object {
        private const val REQUEST_CODE_STORAGE_PERMISSION = 100
    }
}
